var personalDetails = {
  Name: "Chirag Jobanputra",
  Age: 27,
  DateOfBirth: "02-Aug-1989",
  PlaceOfBirth: "Bhopal"
};

console.log(personalDetails);
